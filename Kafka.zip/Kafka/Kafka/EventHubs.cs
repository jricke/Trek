﻿using Microsoft.Azure.EventHubs.Core;
using System.Threading.Tasks;

namespace Kafka
{
    public class EventHubs
    {
        public async Task PublishAsync()
        {
            //new Microsoft.Azure.EventHubs.Processor.EventProcessorHost().RegisterEventProcessorAsync()
            //await Task.CompletedTask;
            //Microsoft.Azure.EventHubs.EventHubClient.Create(new Microsoft.Azure.EventHubs.EventHubsConnectionStringBuilder(null)).SendAsync()

            await Task.CompletedTask;
        }
    }
}

﻿using Avro;
using Avro.Generic;
using Confluent.Kafka.SyncOverAsync;
using Confluent.SchemaRegistry.Serdes;
using Confluent.SchemaRegistry;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;

namespace Kafka
{
    class Program
    {
        static void Main(string[] args)
        {
            var f = Avro.Schema.Parse(@"[
  {
    ""type"": ""record"",
    ""namespace"": ""Kafka.Events"",
    ""name"": ""EventA"",
    ""fields"": [
      {
        ""name"": ""Id"",
        ""type"": ""string""
      },
      {
                ""name"": ""TimeOfEvent"",
        ""type"": ""string""
      }
    ]
  },
  {
    ""type"": ""record"",
    ""namespace"": ""Kafka.Events"",
    ""name"": ""EventB"",
    ""fields"": [
      {
        ""name"": ""Id"",
        ""type"": ""string""
      },
      {
        ""name"": ""TimeOfEvent"",
        ""type"": ""string""
      }
    ]
  }
]");

            var d = new GenericRecord((RecordSchema)RecordSchema.Parse(@"{
    ""type"": ""record"",
    ""namespace"": ""Kafka.Events"",
    ""name"": ""EventA"",
    ""fields"": [
      {
        ""name"": ""Id"",
        ""type"": ""string""
      },
      {
                ""name"": ""TimeOfEvent"",
        ""type"": ""string""
      }
    ]
  }"));
            UnionSchema e = (UnionSchema)Avro.Schema.Parse(@"[{
    ""type"": ""record"",
    ""namespace"": ""Kafka.Events"",
    ""name"": ""EventA"",
    ""fields"": [
      {
        ""name"": ""Id"",
        ""type"": ""string""
      },
      {
                ""name"": ""TimeOfEvent"",
        ""type"": ""int"",
        ""logicaltype"": ""date""
      }
    ]
  },
  {
    ""type"": ""record"",
    ""namespace"": ""Kafka.Events"",
    ""name"": ""EventB"",
    ""fields"": [
      { ""name"": ""EventA"", ""type"": ""EventA"" }
    ]
  }
]");
            var config = TelemetryConfiguration.CreateDefault();
            config.InstrumentationKey = "dummy";
            config.TelemetryChannel.EndpointAddress = "https://localhost:44306/api/values";
            
            var client = new Microsoft.ApplicationInsights.TelemetryClient(config);
            TelemetryConfiguration.Active
            //client.TrackEvent("TestEvent");

            using (var operation = client.StartOperation<RequestTelemetry>("test request operation"))
            {
                client.TrackEvent("SDF");

                operation.Telemetry.ResponseCode = "200";
                operation.Telemetry.Success = true;
            }
            

            client.Flush();
            //Debug.WriteLine(Microsoft.Hadoop.Avro.AvroSerializer.Create<EventA>().WriterSchema.ToString());
            //Debug.WriteLine(Microsoft.Hadoop.Avro.AvroSerializer.Create<BaseEvent<EventB>>().WriterSchema.ToString());
            //Task.Run(() => new Kafka().ConsumeAsync().GetAwaiter().GetResult());
            //new Kafka().PublishAsync().GetAwaiter().GetResult();
        }
    }
    
    public class DataHubTelemetryClient
    {
        private readonly TelemetryClient _telemetryClient;

        public DataHubTelemetryClient(TelemetryClient telemetryClient)
        {
            _telemetryClient = telemetryClient ?? throw new ArgumentNullException(nameof(telemetryClient));
        }

        public void TrackEvent(Event @event)
        {
            client.TrackEvent(@event.GetType().FullName);

        }
    }

    public class Event
    {

    }

    public class D : ITelemetryChannel
    {
        public bool? DeveloperMode { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string EndpointAddress { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public void Flush()
        {
            throw new NotImplementedException();
        }

        public void Send(ITelemetry item)
        {
            Debug.WriteLine(item.Context.Cloud.ToString());
        }
    }

}

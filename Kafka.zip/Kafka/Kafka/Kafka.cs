﻿using Avro.Generic;
using Confluent.Kafka;
using Confluent.Kafka.SyncOverAsync;
using Confluent.SchemaRegistry;
using Confluent.SchemaRegistry.Serdes;
using System;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Kafka
{
    [DataContract]
    public class BaseEvent<T>
    {
        [DataMember]
        public string ComponentId { get; set; }

        [DataMember]
        public T Data { get; set; }
    }

    [DataContract]
    public class EventA
    {
        //[DataMember]
        //public BaseEvent Data { get; set; }
        [DataMember]
        public string PropA { get; set; }

        [DataMember]
        public Guid PropB { get; set; }
    }

    [DataContract]
    public class EventB
    {
        [DataMember]
        public string PropB { get; set; }
    }



    public class Kafka
    {
        public async Task PublishAsync()
        {
            //var config = new ProducerConfig { BootstrapServers = "localhost:9092" };
            var config = new ProducerConfig
            {
                BootstrapServers = "jasonrtest.servicebus.windows.net:9093",
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SaslMechanism = SaslMechanism.Plain,
                SaslUsername = "$ConnectionString",
                SaslPassword = "Endpoint=sb://jasonrtest.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=FmjZpePPmLOBRT8PkSE8oiKm4fJymCsgDeT2XTyItOk="
            };
            //var schemaRegistryConfig = new SchemaRegistryConfig
            //{
            //    SchemaRegistryUrl = "localhost:8081"
            //};
            // If serializers are not specified, default serializers from
            // `Confluent.Kafka.Serializers` will be automatically used where
            // available. Note: by default strings are encoded as UTF8.
            //using (var p = new ProducerBuilder<Null, string>(config).SetValueSerializer(new AvroSerializer<string>(new CachedSchemaRegistryClient(schemaRegistryConfig))).Build())
            using (var p = new ProducerBuilder<Null, string>(config).Build())
            {
                try
                {
                    var dr = await p.ProduceAsync("test", new Message<Null, string> {  Value = "test message" });
                    Console.WriteLine($"Delivered '{dr.Value}' to '{dr.TopicPartitionOffset}'");
                }
                catch (ProduceException<Null, string> e)
                {
                    Console.WriteLine($"Delivery failed: {e.Error.Reason}");
                }
            }
        }

        public async Task ConsumeAsync()
        {
            var schemaRegistryConfig = new SchemaRegistryConfig
            {
                SchemaRegistryUrl = "localhost:8081"
            };
            
            var d = new ConsumerConfig { BootstrapServers = "localhost:9092", GroupId = "test-group" };
            using (var c = new ConsumerBuilder<Null, string>(d).SetValueDeserializer(new AvroDeserializer<string>(new CachedSchemaRegistryClient(schemaRegistryConfig)).AsSyncOverAsync()).Build())
            {
                c.Subscribe("test");

                try
                {
                    while (true)
                    {
                        try
                        {
                            var consumeResult = c.Consume();

                            Console.WriteLine($"key: {consumeResult.Message.Key}, body: {consumeResult.Value}");
                        }
                        catch (ConsumeException e)
                        {
                            Console.WriteLine($"Consume error: {e.Error.Reason}");
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                    c.Close();
                }
            }
        }
    }
}

﻿namespace Kafka.Events
{
    public interface ITelemetryEvent
    {
        string Id { get; set; }
    }
}

﻿namespace Kafka.Events
{
    public partial class EventA :  ITelemetryEvent
    {
    }
}

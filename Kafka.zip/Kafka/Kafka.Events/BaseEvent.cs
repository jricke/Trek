﻿using System;

namespace Kafka.Events
{
    public abstract partial class BaseEvent
    {
        public abstract string TimeOfEvent { get; set; }

        protected BaseEvent()
        {
            TimeOfEvent = new DateTime().ToString();
        }
    }
}

﻿namespace Apache.Events
{
    public partial class EventA : BaseEvent
    {
    }
}

﻿using System;

namespace Apache.Events
{
    public abstract class BaseEvent
    {
        public Guid Id { get; }
    }
}
